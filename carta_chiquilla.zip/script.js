document.addEventListener("DOMContentLoaded", function() {
    function createHeart() {
        const heart = document.createElement("div");
        heart.innerHTML = "❤️";
        heart.classList.add("heart");

        // Posición aleatoria en la pantalla
        heart.style.left = Math.random() * 100 + "vw";
        heart.style.top = "100vh";
        heart.style.fontSize = Math.random() * 20 + 10 + "px";

        document.body.appendChild(heart);

        // Eliminar el corazón después de la animación
        setTimeout(() => {
            heart.remove();
        }, 4000);
    }

    // Generar corazones cada 300ms
    setInterval(createHeart, 300);
});